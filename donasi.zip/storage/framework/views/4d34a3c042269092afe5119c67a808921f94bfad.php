
<?php $__env->startSection('content'); ?>
<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
    <h3 class="mt-5">Welcome Admin !!</h3>
    <hr>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GIT\donasi\resources\views/page/admin/dashboard.blade.php ENDPATH**/ ?>