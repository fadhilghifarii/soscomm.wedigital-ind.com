<?php $__env->startSection('content'); ?>
            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4 mb-4">
                <h3 class="mt-5">Input Slider</h3>
                <hr>

                <form method="post" action="<?php echo e(url('/admin/input-slider-submit')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group">
                    <label for="cover_foto_panti_asuhan">Cover Foto Slider <?php echo e($s->id); ?></label>
                    <input type="file" name="foto_slider<?php echo e($s->id); ?>" class="form-control-file">
                </div>
                <div class="form-group">
                    <label for="link_panti_asuhan">Judul Artikel Panti Asuhan <?php echo e($s->id); ?></label>
                    <input type="text" value="<?php echo e($s->judul); ?>" name="judul_slider<?php echo e($s->id); ?>" class="form-control" placeholder="Masukan Judul">
                </div>
                <div class="form-group">
                    <label for="link_panti_asuhan">Deskripsi Artikel Panti Asuhan <?php echo e($s->id); ?></label>
                    <textarea class="form-control" name="desk_slider<?php echo e($s->id); ?>" placeholder="Masukan Deskripsi"><?php echo e($s->deskripsi); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="link_panti_asuhan">Link Artikel Panti Asuhan <?php echo e($s->id); ?></label>
                    <input type="text" value="<?php echo e($s->link); ?>" name="link_slider<?php echo e($s->id); ?>" class="form-control" placeholder="Masukan Link">
                </div>
                <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <button type="submit" class="btn btn-primary">Submit</button>
            </form>


            </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GIT\donasi\resources\views/page/admin/input_slider.blade.php ENDPATH**/ ?>