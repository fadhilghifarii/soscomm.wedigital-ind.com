<?php $__env->startSection('link'); ?>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
    <h3 class="mt-5">Add New Program Donasi</h3>
    <hr>

    <form method="post" action="<?php echo e(url('/admin/edit-program-donasi-submit')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($d->id); ?>" />
        <div class="form-group">
          <label for="nama_program_donasi">Nama Program Donasi</label>
          <input type="text" name="nama" value="<?php echo e($d->nama); ?>" class="form-control" placeholder="Masukan Nama Program Donasi" required>
        </div>

        <div class="form-group">
            <label for="nama_panti_asuhan">Nama Panti Asuhan</label>
            <select class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref" name="panti" required>
                <option disabled>Pilih Panti Asuhan</option>
                <?php $__currentLoopData = $panti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php
                    if($p->id == $d->panti_id){echo"selected";}
                ?> value="<?php echo e($p->id); ?>"><?php echo e($p->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>

          <div class="form-group">
            <label for="kategori_program_donasi">Kategori Program Donasi</label>
            <input type="text" class="form-control" value="<?php echo e($d->ktg); ?>" placeholder="Masukan Kategori Program Donasi" name="ktg" required>
          </div>

          <div class="form-group">
            <label for="foto_program_donasi">Foto Program Donasi</label>
            <input type="file" class="form-control-file" name="foto">
        </div>

        <div class="form-group">
            <label for="progres_realisaasi">Progres Realisasi</label>
            <input type="number" class="form-control" value="<?php echo e($d->progres); ?>" placeholder="Masukan Persentasi Donasi Saat Ini" name="progres" required>
          </div>

          <div class="form-group">
            <label for="target_donasi">Target Donasi</label>
            <input type="number" class="form-control" value="<?php echo e($d->target); ?>" placeholder="Masukan Target Donasi" name="target" required>
          </div>

          <div class="form-group">
            <label for="deskripsi_program_donasi">Deskripsi Program Donasi</label>
            <textarea id="summernote" name="deskripsi" required><?php echo e($d->deskripsi); ?></textarea>

          </div>

          <button type="submit" class="btn btn-primary">Submit</button>


        </form>


</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
<script>
$(document).ready(function(){
    $('#summernote').summernote({
      placeholder: 'Tulis Deskripsi',
      tabsize: 2,
      height: 200
    });
})

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GIT\donasi\resources\views/page/admin/program_donasi_edit.blade.php ENDPATH**/ ?>