<?php $__env->startSection('content'); ?>
            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                <h3 class="mt-5">Donatur</h3>
                <hr>

                
                <h6>List Donatur</h6>
                  <table class="table">
                    <thead class="thead-light">
                      <tr>
                        <th scope="col">No</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Email</th>
                        <th scope="col">No Telepon</th>
                        

                      </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <th scope="row"><?php echo e($no++); ?></th>
                      <td><?php echo e($u->name); ?></td>
                      <td><?php echo e($u->email); ?></td>
                      <td>
                        <?php
                        if(!empty($u->hp)){
                            echo $u->hp;
                        }else{
                            echo "Tidak Ada";
                        }
                        ?>
                      </td>
                      
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
            </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GIT\donasi\resources\views/page/admin/donatur.blade.php ENDPATH**/ ?>