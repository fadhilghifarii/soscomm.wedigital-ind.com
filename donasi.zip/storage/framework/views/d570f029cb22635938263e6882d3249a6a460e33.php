<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Bootstrap CSS -->
    <title>Admin - <?php echo e($title); ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <?php echo $__env->yieldContent('link'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dashboard.css')); ?>">

  </head>
  <body>
    <nav class="navbar navbar-dark bg-dark fixed-top flex-md-nowrap p-0 shadow">
       <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="<?php echo e(url('/admin/dashboard')); ?>">Admin Dashboard</a>
       <ul class="navbar-nav px-3">
            <li class="nav-item text-nowrap">
                <a class="nav-link" href="#" id="logout">Logout</a>
            </li>
       </ul>
      </nav>

      <div class="container">
        <div class="row">
            <div class="col-md-2 bg-light d-none d-md-block sidebar">
                <div class="left-sidebar">
                    <ul class="nav flex-column sidebar-nav">
                        <li class="nav-item">
                          <a class="nav-link active" href="<?php echo e(url('/admin/panti')); ?>">Panti</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="<?php echo e(url('/admin/program-donasi')); ?>">Program Donasi</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="<?php echo e(url('/admin/donatur')); ?>">Donatur</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/admin/input-slider')); ?>">Slider</a>
                          </li>
                      </ul>

                </div>
            </div>

            <?php echo $__env->yieldContent('content'); ?>
        </div>
      </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <?php echo $__env->yieldContent('script'); ?>
    <script>
    $(document).ready(function(){
        $('#logout').click(function(){
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                method: 'POST',
                url: "<?php echo e(route('logout')); ?>",
                success:function(res){
                    console.log("loading...");
                    window.location.href = "<?php echo e(route('home')); ?>";
                }
            })
        })
    })
    </script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\GIT\donasi\resources\views/layouts/admin_header.blade.php ENDPATH**/ ?>