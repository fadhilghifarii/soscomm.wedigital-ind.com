@extends('layouts.admin_header')
@section('content')
<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
    <h3 class="mt-5">Welcome Admin !!</h3>
    <hr>
</main>
@endsection
